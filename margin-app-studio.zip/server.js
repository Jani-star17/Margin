const express = require("express");
const Database = require("better-sqlite3");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || "change-me";
const MAX_TEXT = 500000;
const MAX_TITLE = 200;
const MAX_AUTHOR = 120;
const MAX_REPORT = 1000;
const MAX_IMAGE_PROMPT = 32000;
const MAX_IMAGE_DATA = 20 * 1024 * 1024;
const IMAGE_MODEL = process.env.MARGIN_IMAGE_MODEL || "gpt-image-2.5-sunburst";

app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: false, limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));

const db = new Database(path.join(__dirname, "margin.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS books (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  author TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL,
  text TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  ip_hash TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  book_id INTEGER NOT NULL,
  reason TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  ip_hash TEXT NOT NULL,
  FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_books_title ON books(title);
CREATE INDEX IF NOT EXISTS idx_books_author ON books(author);
CREATE INDEX IF NOT EXISTS idx_books_category ON books(category);
`);

const allowedCategories = new Set(["school","college","fiction","nonfiction","other"]);
const customCategories = new Set();

function ipHash(req) {
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "");
  return crypto.createHash("sha256").update(ip).digest("hex");
}

const buckets = new Map();
function rateLimit(limit, windowMs) {
  return (req, res, next) => {
    const key = ipHash(req);
    const now = Date.now();
    let b = buckets.get(key);
    if (!b || now - b.start > windowMs) b = { start: now, count: 0 };
    b.count++;
    buckets.set(key, b);
    if (b.count > limit) return res.status(429).json({ error: "Too many requests. Please try again later." });
    next();
  };
}

app.get("/api/health", (_req,res) => res.json({ ok:true, name:"Margin" }));

app.get("/api/categories", (_req,res) => {
  const base = ["school","college","fiction","nonfiction","other"];
  const user = [...customCategories].filter(x => !base.includes(x));
  res.json({ categories: [...base, ...user].slice(0, 50) });
});

app.post("/api/categories", rateLimit(10, 60*60*1000), (req,res) => {
  const name = String(req.body.name || "").trim().replace(/\s+/g," ");
  if (!name || name.length > 40 || !/^[\p{L}\p{N} _-]+$/u.test(name))
    return res.status(400).json({error:"Invalid category"});
  customCategories.add(name.toLowerCase());
  res.status(201).json({category:name.toLowerCase()});
});

app.get("/api/books", rateLimit(120, 60*60*1000), (req,res) => {
  const q = String(req.query.q || "").trim();
  const category = String(req.query.category || "").trim().toLowerCase();
  const limit = Math.min(Math.max(Number(req.query.limit || 30),1),50);
  const terms = [];
  const params = {};
  let sql = "SELECT id,title,author,category,created_at FROM books WHERE 1=1";
  if (q) {
    sql += " AND (title LIKE @q OR author LIKE @q)";
    params.q = `%${q.replace(/[%_]/g, "\\$&")}%`;
  }
  if (category) { sql += " AND category = @category"; params.category = category; }
  sql += " ORDER BY id DESC LIMIT @limit";
  params.limit = limit;
  res.json({books: db.prepare(sql).all(params)});
});

app.get("/api/books/:id", (req,res) => {
  const id = Number(req.params.id);
  const book = db.prepare("SELECT id,title,author,category,text,created_at FROM books WHERE id=?").get(id);
  if (!book) return res.status(404).json({error:"Book not found"});
  res.json({book});
});

app.post("/api/books", rateLimit(8, 60*60*1000), (req,res) => {
  const title = String(req.body.title || "").trim();
  const author = String(req.body.author || "").trim();
  const category = String(req.body.category || "other").trim().toLowerCase();
  const text = String(req.body.text || "").trim();
  if (!title || title.length > MAX_TITLE) return res.status(400).json({error:"Title is required and must be 200 characters or fewer."});
  if (author.length > MAX_AUTHOR) return res.status(400).json({error:"Author name is too long."});
  if (!text || text.length < 20 || text.length > MAX_TEXT) return res.status(400).json({error:`Text must be 20-${MAX_TEXT} characters.`});
  if (!allowedCategories.has(category) && !customCategories.has(category)) return res.status(400).json({error:"Choose a valid category."});
  const result = db.prepare("INSERT INTO books(title,author,category,text,ip_hash) VALUES(?,?,?,?,?)")
    .run(title, author, category, text, ipHash(req));
  res.status(201).json({id:Number(result.lastInsertRowid)});
});

app.post("/api/books/:id/report", rateLimit(10, 60*60*1000), (req,res) => {
  const id = Number(req.params.id);
  const reason = String(req.body.reason || "").trim().slice(0,MAX_REPORT);
  if (!db.prepare("SELECT 1 FROM books WHERE id=?").get(id)) return res.status(404).json({error:"Book not found"});
  if (!reason) return res.status(400).json({error:"Please provide a reason."});
  db.prepare("INSERT INTO reports(book_id,reason,ip_hash) VALUES(?,?,?)").run(id,reason,ipHash(req));
  res.status(201).json({ok:true});
});

app.delete("/api/books/:id", (req,res) => {
  if (req.headers.authorization !== `Bearer ${ADMIN_TOKEN}`) return res.status(401).json({error:"Unauthorized"});
  const result = db.prepare("DELETE FROM books WHERE id=?").run(Number(req.params.id));
  res.json({deleted: result.changes});
});

// Project Gutenberg search proxy. Gutenberg's public catalog API is metadata-only here.
app.get("/api/gutenberg/search", rateLimit(30, 60*60*1000), async (req,res) => {
  const q = String(req.query.q || "").trim();
  if (!q || q.length > 100) return res.status(400).json({error:"Enter a search term."});
  const url = "https://gutendex.com/books/?search=" + encodeURIComponent(q);
  try {
    const r = await fetch(url, {headers:{Accept:"application/json"}});
    if (!r.ok) throw new Error("Gutenberg catalog unavailable");
    const data = await r.json();
    const results = (data.results || []).slice(0,20).map(b => ({
      id:b.id, title:b.title, authors:(b.authors||[]).map(a=>a.name),
      formats:b.formats || {}
    }));
    res.json({results});
  } catch (e) {
    res.status(502).json({error:"Gutenberg search is temporarily unavailable."});
  }
});

// Fetch only an allow-listed Project Gutenberg text URL after the user chooses a result.
// No arbitrary proxying.
app.get("/api/gutenberg/text/:id", rateLimit(20, 60*60*1000), async (req,res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1 || id > 1000000) return res.status(400).json({error:"Invalid Gutenberg ID."});
  const candidates = [
    `https://www.gutenberg.org/cache/epub/${id}/pg${id}.txt`,
    `https://www.gutenberg.org/files/${id}/${id}-8.txt`,
    `https://www.gutenberg.org/files/${id}/${id}.txt`
  ];
  for (const url of candidates) {
    try {
      const r = await fetch(url, {redirect:"follow"});
      const finalUrl = new URL(r.url);
      if (finalUrl.hostname !== "www.gutenberg.org" || !r.ok) continue;
      const text = await r.text();
      if (text.length > MAX_TEXT) return res.status(413).json({error:"Book is too large for this reader."});
      return res.json({text});
    } catch {}
  }
  res.status(404).json({error:"A public-domain text file was not available for this Gutenberg book."});
});


function requireImageAPI(req,res,next){
  if(!process.env.OPENAI_API_KEY) return res.status(503).json({error:"Image Studio is not connected yet. Set OPENAI_API_KEY on the server first."});
  next();
}
function cleanPrompt(value){
  const prompt=String(value||"").trim();
  if(!prompt || prompt.length>MAX_IMAGE_PROMPT) return null;
  return prompt;
}
function imagePayload(body){
  const model=String(body.model||IMAGE_MODEL);
  const allowedModels=new Set(["gpt-image-2.5-sunburst","gpt-image-2.5-flare","gpt-image-2.5-sunburst-2026-09-08","gpt-image-2.5-flare-2026-09-08"]);
  return {
    model:allowedModels.has(model)?model:IMAGE_MODEL,
    prompt:cleanPrompt(body.prompt),
    size:["auto","1024x1024","1024x1536","1536x1024"].includes(body.size)?body.size:"1024x1024",
    quality:["auto","low","medium","high","xhigh","max"].includes(body.quality)?body.quality:"high",
    background:["auto","opaque","transparent"].includes(body.background)?body.background:"auto",
    output_format:["png","jpeg","webp"].includes(body.output_format)?body.output_format:"png",
    n:Math.min(Math.max(Number(body.n||1),1),4)
  };
}
async function openaiJSON(url, payload){
  const r=await fetch(url,{method:"POST",headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify(payload)});
  const text=await r.text();
  let data;try{data=JSON.parse(text)}catch{data={error:{message:text.slice(0,500)}}}
  if(!r.ok){const msg=data?.error?.message||"Image generation failed.";const err=new Error(msg);err.status=r.status;throw err}
  return data;
}

// Margin Studio: the API key stays on the server; the browser never receives it.
app.post("/api/images/generate", rateLimit(20, 60*60*1000), requireImageAPI, async (req,res)=>{
  const p=imagePayload(req.body||{});
  if(!p.prompt)return res.status(400).json({error:`Prompt is required and must be ${MAX_IMAGE_PROMPT} characters or fewer.`});
  try{
    const data=await openaiJSON("https://api.openai.com/v1/images/generations",p);
    res.json({images:(data.data||[]).map(x=>({b64:x.b64_json||null,url:x.url||null,revisedPrompt:x.revised_prompt||""})).filter(x=>x.b64||x.url),model:p.model});
  }catch(e){res.status(e.status&&e.status<500?e.status:502).json({error:e.message||"Image generation failed."})}
});

app.post("/api/images/edit", rateLimit(20, 60*60*1000), requireImageAPI, async (req,res)=>{
  const prompt=cleanPrompt(req.body?.prompt);
  const image=String(req.body?.image||"");
  if(!prompt)return res.status(400).json({error:`Edit prompt is required and must be ${MAX_IMAGE_PROMPT} characters or fewer.`});
  if(!/^data:image\/(png|jpeg|jpg|webp);base64,/i.test(image) || image.length>MAX_IMAGE_DATA)return res.status(400).json({error:"Please provide a PNG, JPEG, or WebP image under 20 MB."});
  const model=["gpt-image-2.5-sunburst","gpt-image-2.5-flare","gpt-image-2.5-sunburst-2026-09-08","gpt-image-2.5-flare-2026-09-08"].includes(req.body?.model)?req.body.model:IMAGE_MODEL;
  try{
    const data=await openaiJSON("https://api.openai.com/v1/images/edits",{model,images:[{image_url:image}],prompt,background:["auto","opaque","transparent"].includes(req.body?.background)?req.body.background:"auto",output_format:["png","jpeg","webp"].includes(req.body?.output_format)?req.body.output_format:"png",n:1});
    res.json({images:(data.data||[]).map(x=>({b64:x.b64_json||null,url:x.url||null,revisedPrompt:x.revised_prompt||""})).filter(x=>x.b64||x.url),model});
  }catch(e){res.status(e.status&&e.status<500?e.status:502).json({error:e.message||"Image editing failed."})}
});

app.get("*splat", (_req,res) => res.sendFile(path.join(__dirname,"public","index.html")));

app.listen(PORT, () => console.log(`Margin running at http://localhost:${PORT}`));
